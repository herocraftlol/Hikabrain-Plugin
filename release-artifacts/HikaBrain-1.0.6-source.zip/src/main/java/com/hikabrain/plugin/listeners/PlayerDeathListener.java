package com.hikabrain.plugin.listeners;

import com.hikabrain.plugin.HikaBrainPlugin;
import com.hikabrain.plugin.game.GameManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

/**
 * Gère la détection des kills et deaths pour les statistiques (globales + individuelles).
 */
public class PlayerDeathListener implements Listener {

    private final HikaBrainPlugin plugin;

    public PlayerDeathListener(HikaBrainPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        GameManager gm = plugin.getArenaManager().findArenaOf(victim);

        if (gm == null) return;
        if (!gm.isPlaying(victim)) return;

        int teamSize = Math.max(gm.getPlayerCountForTeam(com.hikabrain.plugin.game.Team.RED),
                                gm.getPlayerCountForTeam(com.hikabrain.plugin.game.Team.BLUE));

        Player killer = victim.getKiller();

        if (killer != null && gm.isPlaying(killer) && !killer.equals(victim)) {
            plugin.getStatsManager().addKill(gm.getTeam(killer), teamSize);
            plugin.getStatsManager().addPlayerKill(killer.getUniqueId(), killer.getName(), teamSize);
            gm.addKill(gm.getTeam(killer));
            gm.addPlayerKill(killer.getUniqueId());
        }

        plugin.getStatsManager().addDeath(gm.getTeam(victim), teamSize);
        plugin.getStatsManager().addPlayerDeath(victim.getUniqueId(), victim.getName(), teamSize);
        gm.addDeath(gm.getTeam(victim));
        gm.addPlayerDeath(victim.getUniqueId());
    }
}
